#!/usr/bin/python3
import requests
import os,threading
from requests.exceptions import HTTPError



print("PID of script is",os.getpid())
print("Loadavg is",os.getloadavg())

cpu=os.cpu_count()  #taking cpu core count

for i in range(1,6): #writing 5 times
    
    loadavg=os.getloadavg()  #taking loadavg
    
    
    if(cpu - loadavg[2] < 1): #If the loadavg value is near(or close) to the cpu core count then exit script
        print("The " +str(i)+"loadavg value is " + str(cpu)+"and the cpu core count is "+str(loadavg[2]))
        print("The loadavg is " + str(loadavg))
        sys.exit("The loadavg value is near to cpu core count")
    else:
         print("\nThe "+str(i)+" loadavg value is " + str(cpu)+ " and the cpu core count is " + str(loadavg[2]))
         print("The loadavg is " + str(loadavg))
         


def check_url(arr):
    
    try:
        response = requests.get(arr)

        # If the response was successful, no Exception will be raised
        response.raise_for_status()
    except HTTPError as http_err:
        print("HTTP error occurred: ",response) 
    except Exception as err:
        print("Other error occurred: ")  
    else:
        print("Success! ",response)
        
        
        
thread1 = threading.Thread(target=check_url, args=("https://api.github.com",))
thread2 = threading.Thread(target=check_url, args=("http://bilgisayar.mu.edu.tr/",))
thread3 = threading.Thread(target=check_url, args=("https://www.python.org/",))
thread4 = threading.Thread(target=check_url, args=("http://akrepnalan.com/ceng2034",))
thread5 = threading.Thread(target=check_url, args=("https://github.com/caesarsalad/wow",))

#start threads
thread1.start()
thread2.start()        
thread3.start()
thread4.start()
thread5.start()       
        
        
        
        
        
        
              
        
        
        
     
